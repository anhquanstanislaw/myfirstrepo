//print.h
#ifndef PRINT_H
#define PRINT_H
#include "general.h"

void Game_Print(Game *game);// prints board
#endif