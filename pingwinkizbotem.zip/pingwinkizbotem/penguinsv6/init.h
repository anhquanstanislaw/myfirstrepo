//init.h
#ifndef INIT_H
#define INIT_H
#include "general.h"



void Game_Init(Game *game); // gets dimenstions, number of penguins, generates board
#endif